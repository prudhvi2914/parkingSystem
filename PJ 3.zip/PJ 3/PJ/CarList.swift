//
//  CarList.swift
//  PJ
//
//  Created by satram prudhvi on 2018-11-19.
//  Copyright © 2018 shashank Machani. All rights reserved.
//

import Foundation
class CarList {
    
    static var carTitle : [String] = ["audi", "benz" , "bmw", "cadillac", "chevrolet", "honda", "toyota"]
    
    static var carImages : [String] = [ "audi", "benz" , "bmw", "cadillac", "chevrolet", "honda", "toyota"]
    
    
}
