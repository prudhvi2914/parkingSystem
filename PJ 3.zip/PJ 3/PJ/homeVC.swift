//
//  homeVC.swift
//  PJ
//
//  Created by Shashank Preetham on 2018-11-03.
//  Copyright © 2018 shashank Machani. All rights reserved.
//

import UIKit

class homeVC: UIViewController {
    @IBOutlet weak var lblUserName: UILabel!
    
    @IBOutlet weak var btnSupport: UIButton!
    
    static var arryOfTickets : [Any] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        btnSupport.layer.cornerRadius = 30;
        btnSupport.layer.masksToBounds = true
 
        let ud = UserDefaults.standard
        if let userName = ud.string(forKey: "userName")
        {
            lblUserName.text = "Welcome To Parking Tracking App \n" + userName
        }else{
            lblUserName.text = "no data from user default"
        }
        // Do any additional setup after loading the view.
    }

    @IBAction func btnSupport(_ sender: UIButton) {
        let attributedString = NSAttributedString(string: "+1 1234567890                                              9:00 AM - 8:00 PM ET M-F                                             Email: parkingticket@gmail.com", attributes: [NSAttributedString.Key.font : UIFont(name: "Avenir-Light", size: 20)!])
        let alert = UIAlertController(title: "Need Help ?", message: "", preferredStyle: UIAlertController.Style.alert)
        alert.setValue(attributedString, forKey: "attributedMessage")
        let alertAction = UIAlertAction(title: "OK!", style: UIAlertAction.Style.default)
        {
            (UIAlertAction) -> Void in
        }
        alert.addAction(alertAction)
        present(alert, animated: true)
        {
            () -> Void in
        }
    }
    
    @IBAction func btnSignOut(_ sender: UIBarButtonItem) {
//        let mainSb : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
//        let signUpVC = mainSb.instantiateViewController(withIdentifier: "LoginScene")
//        navigationController?.pushViewController(signUpVC, animated: true)
        let alertController = UIAlertController(title: "Logout", message: "Are you sure you want to Logout?", preferredStyle: .alert)
        
        // Create the actions
        let okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default) {
            UIAlertAction in
            NSLog("OK Pressed")
            
            
            self.dismiss(animated: true, completion: nil)

        }
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel) {
            UIAlertAction in
            NSLog("Cancel Pressed")
        }
        
        // Add the actions
        alertController.addAction(okAction)
        alertController.addAction(cancelAction)
        
        // Present the controller
        self.present(alertController, animated: true, completion: nil)


    }
}
