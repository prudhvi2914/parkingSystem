import UIKit

class loginVC: UIViewController {
    
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var switchRemember: UISwitch!
    
    func validateUser() -> Bool {
        if txtEmail.text == "" || txtPassword.text == "" {
          //  return true
       // }  //else{
            let infoAlert = UIAlertController(title: "Error", message: "All Fields are required.!!", preferredStyle: .alert)
            infoAlert.addAction(UIAlertAction(title: "Retry", style: .default, handler: nil))
            self.present(infoAlert, animated: true, completion: nil)
            return false
        }
        let u  = User.searchUser(userEmail: txtEmail.text!)
        if u.password == txtPassword.text{
            return true
        } else{
        return false
        }
    }
    
    
    @IBAction func btnSignIn(_ sender: UIButton) {
        if validateUser(){
            
            if switchRemember.isOn{
                //save Data
                UserDefaults.standard.set(txtEmail.text, forKey: "email")
                UserDefaults.standard.set(txtPassword.text, forKey: "password")
                UserDefaults.standard.set(switchRemember.isOn, forKey: "rememberme")
                
            }else{
                //remove Data
                if UserDefaults.standard.string(forKey: "email") != nil{
                    UserDefaults.standard.removeObject(forKey: "email")
                }
                
                if UserDefaults.standard.value(forKey: "password") != nil {
                    UserDefaults.standard.removeObject(forKey: "password")
                }
                
                UserDefaults.standard.set(switchRemember.isOn, forKey: "rememberme")
            }
//                        
            if let tabbar = (storyboard?.instantiateViewController(withIdentifier: "tabbar") as? UITabBarController) {
                self.present(tabbar, animated: true, completion: nil)
        }else{
            let infoAlert = UIAlertController(title: "Invalid User", message: "Incorrect Username and/or Password", preferredStyle: .alert)
            infoAlert.addAction(UIAlertAction(title: "Retry", style: .default, handler: nil))
            self.present(infoAlert, animated: true, completion: nil)
        }
    }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let email = UserDefaults.standard.string(forKey: "email"){
            txtEmail.text = email
        }
        if let password = UserDefaults.standard.value(forKey: "password") {
            txtPassword.text = password as? String
            txtPassword.isSecureTextEntry = true
        }
        let switchR = UserDefaults.standard.bool(forKey: "rememberme")
        self.switchRemember.setOn(switchR, animated: true)
    }
    
    @IBAction func btnSignUp(_ sender: UIButton) {
        let mainSb : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let signUpVC = mainSb.instantiateViewController(withIdentifier: "SignUpScene")
        navigationController?.pushViewController(signUpVC, animated: true)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
}

